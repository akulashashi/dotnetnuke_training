function JB_GetActiveContent(strWriteBack){
document.write(strWriteBack);
}